import SwiftUI

struct ContentView: View {
    init() {
    
        let tabBarAppearance = UITabBarAppearance()
        tabBarAppearance.configureWithOpaqueBackground()
        tabBarAppearance.backgroundColor = .black
        UITabBar.appearance().standardAppearance = tabBarAppearance
        if #available(iOS 15.0, *) {
            UITabBar.appearance().scrollEdgeAppearance = tabBarAppearance
        }
    }
    
    var body: some View {
        TabView {
            ViewHome()
                .tabItem {
                    Image(systemName: "house")
                    Text("Hjem")
                }
            ViewA()
                .tabItem {
                    Image(systemName: "pencil.tip")
                    Text("Tegn")
                }
            ViewB()
                .tabItem {
                    Image(systemName: "pencil.and.outline")
                    Text("Freeform")
                }
            ViewC()
                .tabItem {
                    Image(systemName: "doc.plaintext")
                    Text("Materialer")
                }
            ViewD()
                .tabItem {
                    Image(systemName: "book.fill")
                    Text("Apps")
                }
            ViewE()
                .tabItem {
                    Image(systemName: "books.vertical")
                    Text("Portfolio")
                }
        }
        .accentColor(.white) 
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
