import SwiftUI

struct ViewHome: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let images = [
        "app1", "app2", "app3", "app4", "app5", "app6"
    ]
    
    let imageTexts = [
        "1. An App About Apps\nThis is a design process that takes you all the way from developing ideas to creating app prototypes, and finally to having a completed app. This info button gives you an overview of the app's content.",
        "2. Draw\nUnder the Draw tab, you can use the built-in toolkit to sketch and explain your ideas, as well as develop layouts. By clicking on Idea Generation, you can sketch 8 app ideas, which you can later use to select the best one. Under Blank, iPhone and iPad you can design layouts for your app in different formats.",
        "3. Freeform\nBy clicking on Freeform, you have the option to download a mind map in Freeform, which can be used to connect all your ideas related to your app. In the mind map, you will be able to drag different types of buttons, iPhone frames, and sticky notes into your workspace. If you prefer, you can also create a traditional mind map on paper.",
        "4. Materials\nUnder Materials you have the option to download Keynote materials where you can develop prototypes for your app, whether it's for Apple Watch, iPhone, iPad, or MacBook. Each Keynote theme is unique, featuring a range of templates for your slide layouts. Additionally, you can download teaching materials for the project, as well as activities for students. Furthermore, if you wish, you can download specific teaching materials related to coding in Swift.",
        "5. Apps\nUnder the Apps tab, you can learn how to get started with coding in Swift. Here, you can explore Apple's materials, Get Started with Code and About Me. Unique to An App About Apps, you have the option to download 4 apps, where you will learn how to create Navigation Bars (menus), Stack Views (placement of objects), Insert Content (adding text, images, videos, and links), and Things To Get You Started (a mix of various useful functions for your app).",
        "6. Portfolio\nIn the Portfolio section, you can update and document your journey from idea, layout, feedback, and prototypes to the final app. In Portfolio, you can upload photos from your camera roll and describe your experiences with text. At the bottom of the Portfolio, you can add more image and text boxes."
    
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                
                let imageSize = geometry.size.width / 10.65
                
                VStack(alignment: .center, spacing: 30) {
                    Text("An App About Apps")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 255 / 255, green: 150 / 255, blue: 141 / 255))
                        .padding(.top, 60)
                        .frame(maxWidth: 600)
                    
                    Image("LOGO")
                        .resizable()
                        .aspectRatio(2.4/1, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .padding(-30)
                    
                    
                    Text("An App About Apps is about moving from developing ideas for needed apps to sketching and describing those ideas and creating app prototypes. If you wish, you can also work on learning to code in Swift, so you can eventually publish a real app on the App Store. Turn your visions and ideas into reality! Click The information button to get an overview of the different sections off the app")
                        .font(.system(size: 20, weight: .regular)) 
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) 
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    Text("Click The information button to get an overview of the different sections of the app.")
                        .font(.system(size: 20, weight: .regular)) 
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) 
                        .frame(maxWidth: 800)
                        .multilineTextAlignment(.center)
                    
                    
                }
                .padding(.bottom, 100)
                
                Spacer()
                
                    .padding()
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            showPopup.toggle()
                        }) {
                            Image(systemName: "info.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.black)
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                    }
                }
                
                if showPopup {
                    PopupView2(showPopup: $showPopup, images: images, imageTexts: imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                        .transition(.scale)
                        .zIndex(1)
                }
                
                if let index = fullscreenImageIndex {
                    FullScreenImageView(images: images, imageTexts: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                        .zIndex(2)
                }
            }
        }
    }
}
struct PopupView2: View {
    @Binding var showPopup: Bool
    let images: [String]
    let imageTexts: [String]
    @State private var currentPage: Int = 0
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("What is an app about apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                fullscreenImageIndex = index
                            }
                        
                        Text(imageTexts[index])
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity, maxHeight: 200)  
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                showPopup = false
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}
struct FullScreenImageView: View {
    let images: [String]
    let imageTexts: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Spacer()
                
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .onTapGesture {
                                fullscreenImageIndex = nil
                            }
                            .padding()
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Text(imageTexts[currentIndex])
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                    )
                    .padding()
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Text("\(currentIndex + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(.bottom, 10)
                
                Spacer()
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}

