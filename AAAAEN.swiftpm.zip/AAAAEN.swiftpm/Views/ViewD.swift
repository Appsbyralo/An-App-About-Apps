import SwiftUI

struct ViewD: View {
    
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
               
                VStack {
                    Text("Apps that you can use as building blocks and inspiration")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("On this page, you need to describe what should be included in your app, how it should look, and why it should be included. This work should be compiled in a whiteboard document in Freeform. We have created a template for you. You can download it by pressing the Freeform app icon below. Once you have downloaded the document, you need to duplicate it. Learn how in the information button on this page.")
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10) 
                        .minimumScaleFactor(0.5) 
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Get started with code", description: "A great place to start your coding journey.", linkURL: "")
                        
                        contentBox(title: "About Me", description: "Create a project aboout yourself and learn how to code while building your first app ", linkURL: "https://dr.dk")
                        
                        contentBox(title: "Create a navigation bar", description: "Learn how to build a navigation bar with three tabs. You can add more!", linkURL: "https://app.box.com/s/v7igbf3w0fvybgqnetqkss8h6nwgjzc8")
                        
                        contentBox(title: "Stack Views", description: "Learn how to arrange things in horizontal, vertical, and Z-axis - or a combination.", linkURL: "https://app.box.com/s/4viy18i6myzc52vyzc1tu2xihbyraro2")
                        
                        contentBox(title: "Insert content", description: "Learn how to add video, photos, or add a link to your app.", linkURL: "https://app.box.com/s/8z43rgjkinlq3nouj71adwb896hyegf6")
                        
                        contentBox(title: "Things to get you started", description: "A mix of ideas to get you started building your own app", linkURL: "https://dr.dk")
                    }
                    .padding()
                }
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black) 
            
            Divider()  
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black) 
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)  
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }
}

struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}

