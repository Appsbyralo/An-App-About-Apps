import SwiftUI

struct ViewC: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    let images = [
        "keynote1", "keynote2", "keynote3", "keynote4", "keynote5", "keynote6", "keynote7"
    ] + [
        "shortcuts", "shortcut1", "shortcut2", "shortcut3", "shortcut4", "shortcut5", "shortcut6", "shortcut7"
    ]
    
    @State private var imageTexts = [
        "1. Here, you can download the Idea Compass to choose your best idea. You can also download AppGPT, a chatbot to develop your app idea, a One Pager presentation to pitch your app idea, and an analysis of your favorite app.",
        "2. iPad Prototype App in Keynote\nIn this Keynote file, you get a tailored Keynote theme to develop your prototype app for an iPad. By clicking + to add a new slide, you can select from a range of layouts to best express your ideas.",
        "3. iPhone Prototype App in Keynote\nIn this Keynote file, you receive a customized Keynote theme for developing your prototype app for an iPhone. By clicking + to add a new slide, you can choose from various layouts to effectively communicate your ideas.",
        "4. MacBook Prototype App in Keynote\nIn this Keynote file, you are provided with a specialized Keynote theme to create your prototype app for a MacBook. By pressing + to add a new slide, you can pick from different layouts to present your ideas clearly.",
        "5. Apple Watch Prototype App in Keynote\nIn this Keynote file, you are given a unique Keynote theme to design your prototype app for an Apple Watch. By pressing + to insert a new slide, you can choose from a variety of layouts to convey your ideas efficiently.",
        "6. Teaching Materials\nIn Teaching Materials, you gain access to resources that will help you, as a teacher, confidently start the An App About Apps project. You can download a Keynote book that guides you through every facet from idea to prototype app.",
        "7. Teaching Materials in Swift\nAdditionally, you can download a Keynote book focused on getting started with coding in Swift and facilitating the apps under the 'apps' tab in your teaching.",
        "Create a Shortcut for Your App",
        "1. Open the Shortcuts app on your iPad.",
        "2. Press the \"+\" to create a new shortcut to your home screen.",
        "3. Search for Keynote in the search field. Now select the shortcut \"Play Presentation in Viewer Mode.\"",
        "4. Press on the Keynote presentation to select the file that will open when the shortcut is pressed.",
        "5. Now press on the arrow and name your shortcut by pressing \"rename,\" choose an icon for the shortcut, and finally press \"add to home screen.\"",
        "6. Press \"add\" to add the shortcut to your home screen.",
        "7. You have now created a shortcut to your home screen."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            VStack {
                VStack {
                    Text("Create a prototype with page-switching buttons")
                        .font(.title)
                        .foregroundColor(.black)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("On this page, you can download student materials to analyze your app ideas and select your best one. Additionally, you can download materials to work with your favorite app, create a One Pager presentation, and download AppGPT, a chatbot that will challenge your app idea. Furthermore, you can download app prototype files in Keynote, designed for apps on iPad, iPhone, MacBook, and Apple Watch. As a teacher, you can also download teaching materials, including resources for facilitating the teaching project and materials aimed at getting started with coding in Swift.")
                         
                        
                        .font(.subheadline)
                        .foregroundColor(.black)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                        .lineLimit(10)
                        .minimumScaleFactor(0.5)
                        .padding(.bottom, 20)
                }
                
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 20) {
                        contentBox(title: "Student materials", description: "Click here to download the Idea Compass, AppGPT, My Favorite App and the One Pager presentation.", linkURL: "https://appsbyralo.github.io/An-App-About-Apps/index.html")
                       
                        contentBox(title: "App prototype iPad", description: "Click here to download the Keynote file for the iPad prototype. Develop your ideas seamlessly.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20iPad.key")
                        
                        contentBox(title: "App prototype iPhone", description: "Click here to download the Keynote file for the iPhone prototype. Bring your app ideas to life.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20iPhone.key.zip")
                        
                        contentBox(title: "App prototype Mac", description: "Click here to download the Keynote file for the Mac prototype. Design and refine your concepts.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20app%20MacBook.key.zip")
                        
                        contentBox(title: "App prototype Apple Watch", description: "Click here to download the Keynote file for the Watch prototype. Innovate and visualize your app.", linkURL: "https://raw.githubusercontent.com/Appsbyralo/materialsEN/main/Keynote%20prototype%20Apple%20Watch.key")
                       
                        contentBox(title: "Teaching material", description: "An extensive guide to An App About Apps. Download Keynote books to help you get started and teach coding in Swift.", linkURL: "https://app.box.com/s/b6a1m1jguxyx5fp6a476tbo0tfcn6gjf")
                        
                        contentBox(title: "Teaching materals in Swift", description: "Additionally, you can download a Keynote book focused on getting started with coding in Swift and facilitating the apps under the 'apps' tab in your teaching.", linkURL: "https://app.box.com/s/76jghz4hifyu5e4uh8egap5jk21ocwj5")
                    }
                    .padding()
                }
                
                Spacer()
                
                HStack {
                    Spacer()
                    Button(action: {
                        withAnimation {
                            showPopup.toggle()
                        }
                    }) {
                        Image(systemName: "info.circle")
                            .font(.largeTitle)
                            .padding()
                            .foregroundColor(.black)
                            .clipShape(Circle())
                    }
                    .padding(.trailing, 20)
                    .padding(.bottom, 20)
                }
            }
            
            if showPopup {
                PopupView3(showPopup: $showPopup, images: images, imageTexts: $imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                    .transition(.scale)
                    .zIndex(1)
            }
            
            if let index = fullscreenImageIndex {
                FullscreenImageView2(images: images, descriptions: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                    .zIndex(2)
            }
        }
    }
    
    @ViewBuilder
    private func contentBox(title: String, description: String, linkURL: String, actionURL: String? = nil) -> some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.title2)
                .fontWeight(.bold)
                .lineLimit(2)
                .minimumScaleFactor(0.5)
                .foregroundColor(.black)
            
            Divider()
            
            Text(description)
                .font(.subheadline)
                .foregroundColor(.black)
            
            Text("Link")
                .font(.subheadline)
                .foregroundColor(.blue)
                .underline()
                .onTapGesture {
                    if let url = URL(string: linkURL) {
                        UIApplication.shared.open(url)
                    }
                }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(15)
        .shadow(radius: 5)
        .frame(height: 200)
        .padding(.horizontal)
        .onTapGesture {
            if let urlString = actionURL, let url = URL(string: urlString) {
                UIApplication.shared.open(url)
            }
        }
    }
}

struct ViewCDrawingLine {
    var points: [CGPoint]
    var color: Color
}

struct FullscreenImageView2: View {
    let images: [String]
    let descriptions: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        VStack {
                            Image(images[index])
                                .resizable()
                                .scaledToFit()
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = nil
                                    }
                                }
                                .padding()
                            
                            ScrollView {
                                Text(descriptions[index])
                                    .padding()
                                    .background(
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(Color.white)
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 10)
                                                    .stroke(Color.black, lineWidth: 1)
                                            )
                                    )
                                    .padding()
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                            }
                            .frame(maxHeight: 150)
                        }
                        .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                Spacer()
            }
        }
    }
}
struct PopupView3: View {
    @Binding var showPopup: Bool
    let images: [String]
    @Binding var imageTexts: [String]
    @State private var currentPage: Int = 0
    @State private var isFullScreen: Bool = false
    @Binding var fullscreenImageIndex: Int?
    var body: some View {
        VStack(spacing: 20) {
            Text("What is an app about apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        ZStack {
                            Image(images[index])
                                .resizable()
                                .aspectRatio(contentMode: isFullScreen ? .fit : .fill)
                                .frame(width: isFullScreen ? UIScreen.main.bounds.width : 400, height: isFullScreen ? UIScreen.main.bounds.height : 300)
                                .onTapGesture {
                                    withAnimation {
                                        fullscreenImageIndex = index
                                    }
                                }
                            
                            if isFullScreen {
                                VStack {
                                    Spacer()
                                    Text(imageTexts[index])
                                        .font(.body)
                                        .multilineTextAlignment(.center)
                                        .padding()
                                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white).overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.black, lineWidth: 1)))
                                        .padding()
                                        .foregroundColor(.black)
                                }
                                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                                .transition(.opacity)
                            }
                        }
                        
                        if !isFullScreen {
                            ScrollView {
                                Text(imageTexts[index])
                                    .font(.body)
                                    .multilineTextAlignment(.center)
                                    .padding()
                                    .background(Color.white)
                                    .cornerRadius(10)
                                    .frame(maxWidth: .infinity, alignment: .center)
                                    .foregroundColor(.black)
                            }
                            .frame(height: 100)
                        }
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                withAnimation {
                    showPopup = false
                }
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: isFullScreen ? UIScreen.main.bounds.width : 600, height: isFullScreen ? UIScreen.main.bounds.height : 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
} 
    struct ViewC_Previews: PreviewProvider {
        static var previews: some View {
            ViewC()
        }
    }
