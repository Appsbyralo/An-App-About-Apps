import SwiftUI

struct ViewHome: View {
    @State private var showPopup: Bool = false
    @State private var fullscreenImageIndex: Int? = nil
    
    let images = [
        "app1", "app2", "app3", "app4", "app5"
    ]
    
    let imageTexts = [
        "1. Idea Development\nStart by coming up with ideas, problems, and topics that might be interesting to create apps about. Use the Crazy 8 idea development method, where you receive a Keynote document with 8 squares (can also be done on paper, divided into 8 fields), where you must draw and write ideas (1 idea per minute).",
        "2. Draw\nOnce you have chosen your idea from Crazy 8, you should start drawing what the app might look like. This is done in the drawing function in the app, where you can sketch your ideas for content and layout. You must have drawn at least 5 app pages before moving on to the next activity.",
        "3. Mindmap in Freeform\nThen describe what should be included in your app, how it should look, and why it should be included, based on your mockup drawings from Draw. Compile this work in a whiteboard document. We have made a template for you where you can build the various pages yourself.",
        "4. Prototype in Keynote\nNow, you need to create a prototype of what your finished app should look like. Build the prototype in an app template in Keynote, where you have the opportunity to insert images, videos, text, shapes, and link buttons to switch pages.",
        "5. App in Swift\nFinally, you should learn to code an app in Swift. Here you will find a range of codes and resources that can help you create your own app project. Here you have the opportunity to integrate the codes into your own project and change the content to suit the topic of your app."
    ]
    
    var body: some View {
        ZStack {
            LinearGradient(
                gradient: Gradient(colors: [
                    Color(red: 217 / 255, green: 201 / 255, blue: 254 / 255),
                    Color(red: 86 / 255, green: 193 / 255, blue: 255 / 255)
                ]),
                startPoint: .leading,
                endPoint: .trailing
            )
            .edgesIgnoringSafeArea(.all)
            
            GeometryReader { geometry in
                
                let imageSize = geometry.size.width / 10.65
                
                VStack(alignment: .center, spacing: 30) {
                    Text("An App About Apps")
                        .font(.system(size: 50, weight: .bold))
                        .foregroundColor(Color(red: 255 / 255, green: 150 / 255, blue: 141 / 255))
                        .padding(.top, 60)
                        .frame(maxWidth: 600)
                    
                    Image("LOGO")
                        .resizable()
                        .aspectRatio(2.4/1, contentMode: .fit)
                        .padding(.horizontal, imageSize)
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0))
                        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                        .padding(-30)
                    
                    
                    Text("An App About Apps is about moving from developing ideas for needed apps to sketching and describing those ideas and creating app prototypes. If you wish, you can also work on learning to code in Swift, so you can eventually publish a real app on the App Store. Turn your visions and ideas into reality!")
                        .font(.system(size: 20, weight: .regular)) // Smaller font
                        .foregroundColor(Color(red: 1, green: 0.5, blue: 0)) // Matching color
                        .frame(maxWidth: 600)
                        .multilineTextAlignment(.center)
                    
                    
                    
                    
                }
                .padding(.bottom, 100)
                
                Spacer()
                
                    .padding()
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button(action: {
                            showPopup.toggle()
                        }) {
                            Image(systemName: "info.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.black)
                                .clipShape(Circle())
                        }
                        .padding(.trailing, 20)
                        .padding(.bottom, 20)
                    }
                }
                
                if showPopup {
                    PopupView2(showPopup: $showPopup, images: images, imageTexts: imageTexts, fullscreenImageIndex: $fullscreenImageIndex)
                        .transition(.scale)
                        .zIndex(1)
                }
                
                if let index = fullscreenImageIndex {
                    FullScreenImageView(images: images, imageTexts: imageTexts, currentIndex: index, fullscreenImageIndex: $fullscreenImageIndex)
                        .zIndex(2)
                }
            }
        }
    }
}
struct PopupView2: View {
    @Binding var showPopup: Bool
    let images: [String]
    let imageTexts: [String]
    @State private var currentPage: Int = 0
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("What is an app about apps?")
                .font(.headline)
                .padding()
            
            TabView(selection: $currentPage) {
                ForEach(0..<images.count, id: \.self) { index in
                    VStack {
                        Image(images[index])
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 400, height: 300)
                            .onTapGesture {
                                fullscreenImageIndex = index
                            }
                        
                        Text(imageTexts[index])
                            .font(.body)
                            .multilineTextAlignment(.center)
                            .padding()
                            .background(Color.white)
                            .cornerRadius(10)
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                    }
                    .tag(index)
                }
            }
            .tabViewStyle(PageTabViewStyle())
            .frame(width: 600, height: 400)
            
            Text("\(currentPage + 1) of \(images.count)")
                .font(.footnote)
                .padding(-10)
            
            Button(action: {
                showPopup = false
            }) {
                Image(systemName: "xmark.circle")
                    .font(.title2)
                    .padding()
                    .foregroundColor(.black)
                    .cornerRadius(10)
            }
        }
        .frame(width: 600, height: 600)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .padding()
    }
}
struct FullScreenImageView: View {
    let images: [String]
    let imageTexts: [String]
    @State var currentIndex: Int
    @Binding var fullscreenImageIndex: Int?
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            VStack {
                Spacer() // Pushes content to the top
                
                TabView(selection: $currentIndex) {
                    ForEach(0..<images.count, id: \.self) { index in
                        Image(images[index])
                            .resizable()
                            .scaledToFit()
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .onTapGesture {
                                fullscreenImageIndex = nil
                            }
                            .padding()
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle())
                
                Text(imageTexts[currentIndex])
                    .padding()
                    .background(
                        RoundedRectangle(cornerRadius: 10)
                            .fill(Color.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                    )
                    .padding()
                    .foregroundColor(.black)
                    .multilineTextAlignment(.center)
                
                Text("\(currentIndex + 1) of \(images.count)")
                    .font(.footnote)
                    .padding(.bottom, 10)
                
                Spacer() // Pushes content to the bottom
            }
        }
    }
}

struct ViewHome_Previews: PreviewProvider {
    static var previews: some View {
        ViewHome()
    }
}

